Grand Piano YDP - Compact Mobile Edition

Converted by Audio City from the user-supplied FreePats YDP-GrandPiano-20160804.sf2. Original source sound bank produced by Roberto for FreePats using Zenph Studios Yamaha Disklavier Pro Piano Multisamples for OLPC, performed by Dr. Mikhail Krishtal and the Zenph team.

Original samples and modifications: Creative Commons Attribution 3.0 (CC BY 3.0), https://creativecommons.org/licenses/by/3.0/. Attribution and original author details are in LICENSE-ATTRIBUTION.txt.

Technical changes: split SF2 PCM into 121 mono WAV samples, retained five velocity layers and note mapping, shortened samples to 2.2 seconds maximum for memory-limited Android playback, created sample sustain loops. This is a mobile-optimized adaptation, not the complete original SF2.
